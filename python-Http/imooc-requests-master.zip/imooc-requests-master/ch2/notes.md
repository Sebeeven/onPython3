* [什么是HTTP协议?](https://en.wikipedia.org/wiki/Hypertext_Transfer_Protocol)
* [RFC7230](https://tools.ietf.org/html/rfc7230#page-19)
* [urllib和urllib2区别](http://ver007.com/2015/09/22/276.html)
